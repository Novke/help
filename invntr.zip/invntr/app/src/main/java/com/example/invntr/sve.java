package com.example.invntr;

import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.pm.ActivityInfo;
import android.os.Bundle;
import android.widget.ScrollView;

import java.util.ArrayList;
import java.util.List;

public class sve extends AppCompatActivity {

    List<Item> spisak;
    private RecyclerView recyclerView;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sve);
        this.setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);

        recyclerView = findViewById(R.id.rec1);

        ////////////////////////////////////////////////////////
        spisak = new ArrayList<>();
        Item i1 = new Item("Jaje", 3);
        Item i2 = new Item("Sladoled", 10);
        spisak.add(i1);
        spisak.add(i2);
        ////////////////////////////////////////////////////////

        setAdapter();


    }

    private void setAdapter() {
        recyclerAdapter adapter = new recyclerAdapter(spisak);
        RecyclerView.LayoutManager layoutManager = new LinearLayoutManager(getApplicationContext());
        recyclerView.setLayoutManager(layoutManager);
        recyclerView.setItemAnimator(new DefaultItemAnimator());
        recyclerView.setAdapter(adapter);
    }
}