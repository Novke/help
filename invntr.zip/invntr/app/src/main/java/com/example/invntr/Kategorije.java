package com.example.invntr;

import androidx.appcompat.app.AppCompatActivity;

import android.content.pm.ActivityInfo;
import android.os.Bundle;

import java.util.ArrayList;
import java.util.List;

public class Kategorije extends AppCompatActivity {

    List<Item> spisak;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_kategorije);
        this.setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);

        ////////////////////////////////////////////////////////
        spisak = new ArrayList<>();
        Item i1 = new Item("Jaje", 3);
        Item i2 = new Item("Sladoled", 10);
        spisak.add(i1);
        spisak.add(i2);
        ////////////////////////////////////////////////////////
    }
}