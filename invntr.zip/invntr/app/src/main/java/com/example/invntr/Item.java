package com.example.invntr;

import java.io.Serializable;

public class Item implements Serializable {

    private int id=0;
    private String ime;
    private String opis="";
    private int kolicina;

    public Item(String ime, int kolicina) {
        this.ime = ime;
        this.kolicina = kolicina;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getIme() {
        return ime;
    }

    public void setIme(String ime) {
        this.ime = ime;
    }

    public String getOpis() {
        return opis;
    }

    public void setOpis(String opis) {
        this.opis = opis;
    }

    public int getKolicina() {
        return kolicina;
    }

    public void setKolicina(int kolicina) {
        this.kolicina = kolicina;
    }

    public void dodaj(int x){
        kolicina+=x;
    }

    public  void oduzmi(int x){
        kolicina-=x;
    }

    public void dodaj(){
        kolicina++;
    }

    public void oduzmi(){
        kolicina--;
    }
}
