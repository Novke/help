package com.example.invntr;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class recyclerAdapter extends RecyclerView.Adapter<recyclerAdapter.MyViewHolder>{

    private List<Item> spisak;

    public recyclerAdapter(List<Item> s){
        super();
        spisak=s;
    }

    public class MyViewHolder extends RecyclerView.ViewHolder{
        private TextView tIme, tKol, tOpis;

        public MyViewHolder(final View view){
            super(view);
            tIme=view.findViewById(R.id.ItemNaslov);
            tKol=view.findViewById(R.id.ItemKolicina);
           // tOpis=view.findViewById(R.id.ItemOpis);
        }
    }


    @NonNull
    @Override
    public recyclerAdapter.MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext()).inflate(R.layout.kategorije_recycler, parent, false);
        return new MyViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(@NonNull recyclerAdapter.MyViewHolder holder, int position) {
        String ime = spisak.get(position).getIme();
        if (holder.tIme!=null) holder.tIme.setText(ime);

        //String opis = spisak.get(position).getOpis();
        //if (holder.tOpis!=null) holder.tOpis.setText(opis);

        int kol = spisak.get(position).getKolicina();
        if (holder.tKol!=null) holder.tKol.setText(Integer.toString(kol));
    }

    @Override
    public int getItemCount() {
        return spisak.size();
    }
}
